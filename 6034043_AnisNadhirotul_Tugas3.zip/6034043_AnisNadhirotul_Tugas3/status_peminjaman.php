<?php
// Data Anggota
$nama_anggota = "Budi Santoso";
$total_pinjaman = 2;
$buku_terlambat = 1;
$hari_keterlambatan = 5;

// Menghitung denda
$denda = $buku_terlambat * $hari_keterlambatan * 1000;

// Maksimal denda 50.000
if ($denda > 50000) {
    $denda = 50000;
}

// Cek status peminjaman (IF-ELSEIF-ELSE)
if ($buku_terlambat > 0) {
    $status = "Tidak boleh meminjam (Ada buku terlambat)";
    $warna = "danger";
} elseif ($total_pinjaman >= 3) {
    $status = "Tidak boleh meminjam (Maksimal pinjaman tercapai)";
    $warna = "warning";
} else {
    $status = "Boleh meminjam buku";
    $warna = "success";
}

// Menentukan level member (SWITCH)
switch (true) {
    case ($total_pinjaman >= 0 && $total_pinjaman <= 5):
        $level = "Bronze";
        break;
    case ($total_pinjaman >= 6 && $total_pinjaman <= 15):
        $level = "Silver";
        break;
    case ($total_pinjaman > 15):
        $level = "Gold";
        break;
    default:
        $level = "Tidak diketahui";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Status Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Status Peminjaman Anggota</h2>
    
    <div class="card mt-3">
        <div class="card-body">
            <p><strong>Nama Anggota:</strong> <?php echo $nama_anggota; ?></p>
            <p><strong>Total Pinjaman:</strong> <?php echo $total_pinjaman; ?> buku</p>
            <p><strong>Buku Terlambat:</strong> <?php echo $buku_terlambat; ?> buku</p>
            <p><strong>Hari Keterlambatan:</strong> <?php echo $hari_keterlambatan; ?> hari</p>
            <p><strong>Level Member:</strong> <?php echo $level; ?></p>
            <p><strong>Total Denda:</strong> Rp <?php echo number_format($denda,0,',','.'); ?></p>
            
            <div class="alert alert-<?php echo $warna; ?>">
                <?php echo $status; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>