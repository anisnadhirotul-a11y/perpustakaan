<?php
require_once 'functions_anggota.php';

$anggota_list = [
    ["id"=>"AGT-001","nama"=>"Budi","email"=>"budi@email.com","telepon"=>"08","alamat"=>"Jakarta","tanggal_daftar"=>"2024-01-15","status"=>"Aktif","total_pinjaman"=>5],
    ["id"=>"AGT-002","nama"=>"Siti","email"=>"siti@email.com","telepon"=>"08","alamat"=>"Bandung","tanggal_daftar"=>"2024-02-10","status"=>"Aktif","total_pinjaman"=>8],
    ["id"=>"AGT-003","nama"=>"Andi","email"=>"andi@email.com","telepon"=>"08","alamat"=>"Surabaya","tanggal_daftar"=>"2024-03-05","status"=>"Non-Aktif","total_pinjaman"=>2],
    ["id"=>"AGT-004","nama"=>"Dewi","email"=>"dewi@email.com","telepon"=>"08","alamat"=>"Jogja","tanggal_daftar"=>"2024-01-25","status"=>"Aktif","total_pinjaman"=>10],
    ["id"=>"AGT-005","nama"=>"Rudi","email"=>"rudi@email.com","telepon"=>"08","alamat"=>"Medan","tanggal_daftar"=>"2024-02-20","status"=>"Non-Aktif","total_pinjaman"=>1]
];

$total = hitung_total_anggota($anggota_list);
$aktif = hitung_anggota_aktif($anggota_list);
$nonaktif = $total - $aktif;
$rata = hitung_rata_rata_pinjaman($anggota_list);
$teraktif = cari_anggota_teraktif($anggota_list);

$aktif_list = filter_by_status($anggota_list, "Aktif");
$nonaktif_list = filter_by_status($anggota_list, "Non-Aktif");
?>

<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

<h2>Dashboard Anggota</h2>

<div class="row mb-4">
    <div class="col-md-3"><div class="card p-3">Total: <?= $total ?></div></div>
    <div class="col-md-3"><div class="card p-3">Aktif: <?= $aktif ?></div></div>
    <div class="col-md-3"><div class="card p-3">Non Aktif: <?= $nonaktif ?></div></div>
    <div class="col-md-3"><div class="card p-3">Rata: <?= number_format($rata,2) ?></div></div>
</div>

<h4>Anggota Teraktif</h4>
<div class="card p-3 mb-4">
    <?= $teraktif["nama"] ?> (<?= $teraktif["total_pinjaman"] ?> pinjaman)
</div>

<h4>Semua Anggota</h4>
<table class="table table-bordered">
<tr><th>Nama</th><th>Status</th><th>Pinjaman</th></tr>
<?php foreach ($anggota_list as $a): ?>
<tr>
<td><?= $a["nama"] ?></td>
<td><?= $a["status"] ?></td>
<td><?= $a["total_pinjaman"] ?></td>
</tr>
<?php endforeach; ?>
</table>

<h4>Anggota Aktif</h4>
<ul>
<?php foreach ($aktif_list as $a): ?>
<li><?= $a["nama"] ?></li>
<?php endforeach; ?>
</ul>

<h4>Anggota Non-Aktif</h4>
<ul>
<?php foreach ($nonaktif_list as $a): ?>
<li><?= $a["nama"] ?></li>
<?php endforeach; ?>
</ul>

</div>
</body>
</html>