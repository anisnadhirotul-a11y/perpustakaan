<?php
$anggota_list = [
    [
        "id" => "AGT-001",
        "nama" => "Budi Santoso",
        "email" => "budi@email.com",
        "telepon" => "081234567890",
        "alamat" => "Jakarta",
        "tanggal_daftar" => "2024-01-15",
        "status" => "Aktif",
        "total_pinjaman" => 5
    ],
    [
        "id" => "AGT-002",
        "nama" => "Siti Aminah",
        "email" => "siti@email.com",
        "telepon" => "081234567891",
        "alamat" => "Bandung",
        "tanggal_daftar" => "2024-02-10",
        "status" => "Aktif",
        "total_pinjaman" => 8
    ],
    [
        "id" => "AGT-003",
        "nama" => "Andi Wijaya",
        "email" => "andi@email.com",
        "telepon" => "081234567892",
        "alamat" => "Surabaya",
        "tanggal_daftar" => "2024-03-05",
        "status" => "Non-Aktif",
        "total_pinjaman" => 2
    ],
    [
        "id" => "AGT-004",
        "nama" => "Dewi Lestari",
        "email" => "dewi@email.com",
        "telepon" => "081234567893",
        "alamat" => "Yogyakarta",
        "tanggal_daftar" => "2024-01-25",
        "status" => "Aktif",
        "total_pinjaman" => 10
    ],
    [
        "id" => "AGT-005",
        "nama" => "Rudi Hartono",
        "email" => "rudi@email.com",
        "telepon" => "081234567894",
        "alamat" => "Medan",
        "tanggal_daftar" => "2024-02-20",
        "status" => "Non-Aktif",
        "total_pinjaman" => 1
    ]
];

// Statistik
$total = count($anggota_list);

$aktif = 0;
$nonaktif = 0;
$total_pinjaman = 0;
$teraktif = $anggota_list[0];

foreach ($anggota_list as $a) {
    if ($a["status"] == "Aktif") {
        $aktif++;
    } else {
        $nonaktif++;
    }

    $total_pinjaman += $a["total_pinjaman"];

    if ($a["total_pinjaman"] > $teraktif["total_pinjaman"]) {
        $teraktif = $a;
    }
}

$rata = $total_pinjaman / $total;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Anggota</title>
</head>
<body>

<h2>Statistik</h2>
<p>Total Anggota: <?= $total ?></p>
<p>Aktif: <?= $aktif ?></p>
<p>Non-Aktif: <?= $nonaktif ?></p>
<p>Rata-rata Pinjaman: <?= number_format($rata, 2) ?></p>
<p>Teraktif: <?= $teraktif["nama"] ?></p>

<h2>Daftar Anggota</h2>
<table border="1" cellpadding="10">
<tr>
    <th>ID</th>
    <th>Nama</th>
    <th>Status</th>
    <th>Pinjaman</th>
</tr>

<?php foreach ($anggota_list as $a): ?>
<tr>
    <td><?= $a["id"] ?></td>
    <td><?= $a["nama"] ?></td>
    <td><?= $a["status"] ?></td>
    <td><?= $a["total_pinjaman"] ?></td>
</tr>
<?php endforeach; ?>

</table>

</body>
</html>