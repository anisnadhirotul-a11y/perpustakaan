<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Search Advanced</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
<h2>Pencarian Buku Lanjutan</h2>

<?php
// ================= DATA =================
$buku_list = [
["kode"=>"BK01","judul"=>"PHP Dasar","kategori"=>"Programming","pengarang"=>"Budi","penerbit"=>"Informatika","tahun"=>2022,"harga"=>75000,"stok"=>5],
["kode"=>"BK02","judul"=>"Laravel Expert","kategori"=>"Programming","pengarang"=>"Siti","penerbit"=>"Andi","tahun"=>2024,"harga"=>120000,"stok"=>3],
["kode"=>"BK03","judul"=>"MySQL Guide","kategori"=>"Database","pengarang"=>"Andi","penerbit"=>"Graha","tahun"=>2023,"harga"=>90000,"stok"=>0],
["kode"=>"BK04","judul"=>"HTML CSS","kategori"=>"Web Design","pengarang"=>"Dedi","penerbit"=>"Andi","tahun"=>2021,"harga"=>60000,"stok"=>10],
["kode"=>"BK05","judul"=>"Networking Basic","kategori"=>"Networking","pengarang"=>"Rina","penerbit"=>"Erlangga","tahun"=>2020,"harga"=>85000,"stok"=>2],
["kode"=>"BK06","judul"=>"JavaScript Modern","kategori"=>"Programming","pengarang"=>"Ayu","penerbit"=>"Informatika","tahun"=>2024,"harga"=>95000,"stok"=>0],
["kode"=>"BK07","judul"=>"PostgreSQL","kategori"=>"Database","pengarang"=>"Ahmad","penerbit"=>"Graha","tahun"=>2022,"harga"=>100000,"stok"=>7],
["kode"=>"BK08","judul"=>"UI UX Design","kategori"=>"Web Design","pengarang"=>"Nina","penerbit"=>"Andi","tahun"=>2023,"harga"=>80000,"stok"=>6],
["kode"=>"BK09","judul"=>"Cyber Security","kategori"=>"Networking","pengarang"=>"Rudi","penerbit"=>"Erlangga","tahun"=>2024,"harga"=>130000,"stok"=>4],
["kode"=>"BK10","judul"=>"Python AI","kategori"=>"Programming","pengarang"=>"Bambang","penerbit"=>"Informatika","tahun"=>2023,"harga"=>110000,"stok"=>8],
];

// ================= GET =================
$keyword = $_GET['keyword'] ?? '';
$kategori = $_GET['kategori'] ?? '';
$min_harga = $_GET['min_harga'] ?? '';
$max_harga = $_GET['max_harga'] ?? '';
$tahun = $_GET['tahun'] ?? '';
$status = $_GET['status'] ?? 'semua';
$sort = $_GET['sort'] ?? 'judul';

// ================= VALIDASI =================
$errors = [];

if ($min_harga && $max_harga && $min_harga > $max_harga) {
    $errors[] = "Harga minimum tidak boleh lebih besar dari maksimum";
}

if ($tahun && ($tahun < 1900 || $tahun > date('Y'))) {
    $errors[] = "Tahun tidak valid";
}

// ================= FILTER =================
$hasil = [];

foreach ($buku_list as $buku) {
    $match = true;

    if ($keyword && stripos($buku['judul'],$keyword)===false && stripos($buku['pengarang'],$keyword)===false) {
        $match = false;
    }

    if ($kategori && $buku['kategori'] != $kategori) {
        $match = false;
    }

    if ($min_harga && $buku['harga'] < $min_harga) {
        $match = false;
    }

    if ($max_harga && $buku['harga'] > $max_harga) {
        $match = false;
    }

    if ($tahun && $buku['tahun'] != $tahun) {
        $match = false;
    }

    if ($status == 'tersedia' && $buku['stok'] <= 0) {
        $match = false;
    }

    if ($status == 'habis' && $buku['stok'] > 0) {
        $match = false;
    }

    if ($match) $hasil[] = $buku;
}

// ================= SORT =================
usort($hasil, function($a,$b) use ($sort){
    return $a[$sort] <=> $b[$sort];
});

// ================= PAGINATION =================
$page = $_GET['page'] ?? 1;
$limit = 10;
$start = ($page-1)*$limit;
$total = count($hasil);
$data = array_slice($hasil,$start,$limit);

// ================= HIGHLIGHT =================
function highlight($text,$keyword){
    if(!$keyword) return $text;
    return str_ireplace($keyword,"<mark>$keyword</mark>",$text);
}
?>

<!-- ERROR -->
<?php if($errors): ?>
<div class="alert alert-danger">
<?php foreach($errors as $e) echo $e."<br>"; ?>
</div>
<?php endif; ?>

<!-- FORM -->
<form method="GET" class="row g-2 mb-4">
<input class="form-control col" name="keyword" placeholder="Keyword" value="<?= $keyword ?>">
<select name="kategori" class="form-control col">
<option value="">Semua</option>
<option <?= $kategori=='Programming'?'selected':'' ?>>Programming</option>
<option <?= $kategori=='Database'?'selected':'' ?>>Database</option>
</select>

<input type="number" name="min_harga" placeholder="Min" value="<?= $min_harga ?>">
<input type="number" name="max_harga" placeholder="Max" value="<?= $max_harga ?>">
<input type="number" name="tahun" placeholder="Tahun" value="<?= $tahun ?>">

<select name="status">
<option value="semua">Semua</option>
<option value="tersedia" <?= $status=='tersedia'?'selected':'' ?>>Tersedia</option>
<option value="habis" <?= $status=='habis'?'selected':'' ?>>Habis</option>
</select>

<select name="sort">
<option value="judul">Judul</option>
<option value="harga">Harga</option>
<option value="tahun">Tahun</option>
</select>

<button class="btn btn-primary">Cari</button>
</form>

<!-- HASIL -->
<p><strong><?= $total ?> hasil ditemukan</strong></p>

<table class="table table-bordered">
<tr>
<th>Kode</th><th>Judul</th><th>Kategori</th><th>Harga</th><th>Stok</th>
</tr>

<?php foreach($data as $b): ?>
<tr>
<td><?= $b['kode'] ?></td>
<td><?= highlight($b['judul'],$keyword) ?></td>
<td><?= $b['kategori'] ?></td>
<td><?= $b['harga'] ?></td>
<td><?= $b['stok'] ?></td>
</tr>
<?php endforeach; ?>
</table>

<!-- PAGINATION -->
<?php for($i=1;$i<=ceil($total/$limit);$i++): ?>
<a href="?<?= http_build_query(array_merge($_GET,['page'=>$i])) ?>" class="btn btn-sm btn-secondary">
<?= $i ?>
</a>
<?php endfor; ?>

</div>
</body>
</html>